<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BarangKeluar;
use Validator;
class BarangKeluarController extends Controller
{
    //
    function __construct()
    {
    }
      
    public $successStatus=200;

    public function index()
    {
        $Barang = BarangKeluar::all();
        $data = $Barang->toArray();

        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Transaction retrieved successfully.'
        ];

        return response()->json($response, 200);
    }

    public function store(Request $request){
        $input = $request->all();

        $validator = Validator::make($input, [
            'tanggal' => 'required',
            'id_barang' => 'required',
            'qty' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);            
        }

        $Barang = BarangKeluar::create($input);
        $data = $Barang->toArray();
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Transaction stored successfully.'
        ];        
        return response()->json(['success'=>$response], $this->successStatus);
    }
 
 
 
     public function show($id)
    {
        $Barang = BarangKeluar::where('id','=',$id)->get();
        $data = $Barang->toArray();	
        if (is_null($Barang)) {
            $response = [
                'success' => false,
                'data' => 'Empty',
                'message' => 'Transaction not found.'
            ];
            return response()->json($response, 404);
        }


        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Transaction retrieved successfully.'
        ];

        return response()->json($response, 200);
    }
 

    public function update(Request $request, $id)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'tanggal' => 'required',
            'id_barang' => 'required',
            'qty' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Barang = BarangKeluar::where('id','=',$id)->update($input);
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Transaction updated successfully.'
        ];

        return response()->json($response, 200);
    }


    public function destroy(Request $request, $id)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'tanggal' => 'required',
            'id_barang' => 'required',
            'qty' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Barang = BarangKeluar::where('id','=',$id)->delete();
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Transaction deleted successfully.'
        ];

        return response()->json($response, 200);
    }
}
