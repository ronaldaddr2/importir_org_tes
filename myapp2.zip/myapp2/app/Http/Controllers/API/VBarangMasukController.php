<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VBarangMasuk;
use Validator;
class VBarangMasukController extends Controller
{
    //
    function __construct()
    {
    }
      
    public $successStatus=200;

    public function index(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'tanggal_awal' => 'required',
            'tanggal_akhir' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }
        $data = $input;
        $Barang = VBarangMasuk::whereBetween('tanggal',[$data['tanggal_awal'],$data['tanggal_akhir']])->orderBy('tanggal','asc')->get();
        $result = $Barang->toArray();
        $response = [
            'success' => true,
            'Judul' => 'Laporan Penerimaan Barang',            
            'Periode' => $data['tanggal_awal']. ' - ' .$data['tanggal_akhir'],
            'data' => $result,
            'message' => 'Report Transaction retrieved successfully.'
        ];
        return response()->json($response, 200);
    } 
 
 
    public function show(Request $request, $id)
    {
        $input = $request->all();
        $validator = Validator::make($input, [
            'tanggal_awal' => 'required',
            'tanggal_akhir' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }
        $data = $input;
        $Barang = VBarangMasuk::whereBetween('tanggal',[$data['tanggal_awal'],$data['tanggal_akhir']])->where('id_barang','=',$id)->orderBy('tanggal','asc')->get();
        $result = $Barang->toArray();
        $response = [
            'success' => true,
            'Judul' => 'Laporan Penerimaan Barang',            
            'Periode' => $data['tanggal_awal']. ' - ' .$data['tanggal_akhir'],
            'data' => $result,
            'message' => 'Report Transaction retrieved successfully.'
        ];
        return response()->json($response, 200);
    } 
 

}
