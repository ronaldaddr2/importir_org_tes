<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Validator;
class CategoryController extends Controller
{
    //
    function __construct()
    {
    }
      
    public $successStatus=200;

    public function index()
    {
        $Category = Category::all();
        $data = $Category->toArray();

        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Category retrieved successfully.'
        ];

        return response()->json($response, 200);
    }

    public function store(Request $request){
        $input = $request->all();

        $validator = Validator::make($input, [
            'deskripsi' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);            
        }

        $Category = Category::create($input);
        $data = $Category->toArray();
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Category stored successfully.'
        ];        
        return response()->json(['success'=>$response], $this->successStatus);
    }
 
 
 
     public function show($id_cat)
    {
        $Category = Category::where('id_cat','=',$id_cat)->get();
        $data = $Category->toArray();	
        if (is_null($Category)) {
            $response = [
                'success' => false,
                'data' => 'Empty',
                'message' => 'Category not found.'
            ];
            return response()->json($response, 404);
        }


        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Category retrieved successfully.'
        ];

        return response()->json($response, 200);
    }
 

    public function update(Request $request, $id_cat)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'deskripsi' => 'required'
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Category = Category::where('id_cat','=',$id_cat)->update($input);
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Category updated successfully.'
        ];

        return response()->json($response, 200);
    }


    public function destroy(Request $request, $id_cat)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'deskripsi' => 'required'
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Category = Category::where('id_cat','=',$id_cat)->delete();
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Category deleted successfully.'
        ];

        return response()->json($response, 200);
    }
      
}
