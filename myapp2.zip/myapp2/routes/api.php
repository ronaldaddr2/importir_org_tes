<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login', [API\UserController::class, 'login']);
Route::post('/register', [API\UserController::class, 'register']);

Route::group(['middleware' => ['auth:api','roles']], function(){
	Route::post('/details', [API\UserController::class, 'details']);

//role tabel category	
Route::group(['roles'=>['admin','keuangan','accounting']],function(){
    Route::get('/category', [API\CategoryController::class, 'index']);
    Route::post('/category', [API\CategoryController::class, 'store']);
    Route::get('/category/{id}', [API\CategoryController::class, 'show']);
    Route::put('/category/{id}', [API\CategoryController::class, 'update']);
    Route::delete('/category/{id}', [API\CategoryController::class, 'destroy']);
 });
 
 //role tabel Barang
 Route::group(['roles'=>['admin','keuangan','accounting']],function(){
    Route::get('/barang', [API\BarangController::class, 'index']);
    Route::post('/barang', [API\BarangController::class, 'store']);
    Route::get('/barang/{id}', [API\BarangController::class, 'show']);
    Route::put('/barang/{id}', [API\BarangController::class, 'update']);
    Route::delete('/barang/{id}', [API\BarangController::class, 'destroy']);
 });	
	
 //Barang Masuk
 Route::group(['roles'=>['admin','keuangan','accounting','gudang']],function(){
    Route::get('/barangmasuk', [API\BarangMasukController::class, 'index']);
    Route::post('/barangmasuk', [API\BarangMasukController::class, 'store']);
    Route::get('/barangmasuk/{id}', [API\BarangMasukController::class, 'show']);
    Route::put('/barangmasuk/{id}', [API\BarangMasukController::class, 'update']);
    Route::delete('/barangmasuk/{id}', [API\BarangMasukController::class, 'destroy']);
 });	
 
 //Barang Keluar
 Route::group(['roles'=>['admin','keuangan','accounting','gudang']],function(){
    Route::get('/barangkeluar', [API\BarangKeluarController::class, 'index']);
    Route::post('/barangkeluar', [API\BarangKeluarController::class, 'store']);
    Route::get('/barangkeluar/{id}', [API\BarangKeluarController::class, 'show']);
    Route::put('/barangkeluar/{id}', [API\BarangKeluarController::class, 'update']);
    Route::delete('/barangkeluar/{id}', [API\BarangKeluarController::class, 'destroy']);
 }); 

 //Laporan Stok - harian - mingguan - bulanan - tahunan
 Route::group(['roles'=>['admin','keuangan','accounting']],function(){
    Route::get('/lapstok', [API\VStokController::class, 'index']);
    Route::get('/lapstok/{id}', [API\VStokController::class, 'show']);
 }); 


 //Laporan Barang Masuk - harian - mingguan - bulanan - tahunan
 Route::group(['roles'=>['admin','keuangan','accounting','gudang']],function(){
    Route::get('/lap_barangmasuk', [API\VBarangMasukController::class, 'index']);
    Route::get('/lap_barangmasuk/{id}', [API\VBarangMasukController::class, 'show']);
 });

 //Laporan Barang Keluar - harian - mingguan - bulanan - tahunan
 Route::group(['roles'=>['admin','keuangan','accounting','gudang']],function(){
    Route::get('/lap_barangkeluar', [API\VBarangKeluarController::class, 'index']);
    Route::get('/lap_barangkeluar/{id}', [VBarangKeluarController::class, 'show']);
 });


	
});
