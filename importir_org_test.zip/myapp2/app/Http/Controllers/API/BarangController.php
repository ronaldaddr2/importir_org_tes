<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Barang;
use Validator;
class BarangController extends Controller
{
    //
    function __construct()
    {
    }
      
    public $successStatus=200;

    public function index()
    {
        $Barang = Barang::all();
        $data = $Barang->toArray();

        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Barang retrieved successfully.'
        ];

        return response()->json($response, 200);
    }

    public function store(Request $request){
        $input = $request->all();

        $validator = Validator::make($input, [
            'id_barang' => 'required',
            'nama_barang' => 'required',
            'id_cat' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['error'=>$validator->errors()], 401);            
        }

        $Category = Category::create($input);
        $data = $Category->toArray();
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Barang stored successfully.'
        ];        
        return response()->json(['success'=>$response], $this->successStatus);
    }
 
 
 
     public function show($id_brg)
    {
        $Barang = Barang::where('id_barang','=',$id_brg)->get();
        $data = $Barang->toArray();	
        if (is_null($Barang)) {
            $response = [
                'success' => false,
                'data' => 'Empty',
                'message' => 'Barang not found.'
            ];
            return response()->json($response, 404);
        }


        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Barang retrieved successfully.'
        ];

        return response()->json($response, 200);
    }
 

    public function update(Request $request, $id_brg)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'nama_barang' => 'required',
            'id_cat' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Barang = Barang::where('id_barang','=',$id_brg)->update($input);
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Barang updated successfully.'
        ];

        return response()->json($response, 200);
    }


    public function destroy(Request $request, $id_brg)
    {
        $input = $request->all();

        $validator = Validator::make($input, [
            'nama_barang' => 'required',
            'id_cat' => 'required',
        ]);

        if ($validator->fails()) {
            $response = [
                'success' => false,
                'data' => 'Validation Error.',
                'message' => $validator->errors()
            ];
            return response()->json($response, 404);
        }

        $Barang = Category::where('id_barang','=',$id_brg)->delete();
        $data = $input;
        $response = [
            'success' => true,
            'data' => $data,
            'message' => 'Barang deleted successfully.'
        ];

        return response()->json($response, 200);
    }

}
